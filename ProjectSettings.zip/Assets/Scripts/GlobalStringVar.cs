using UnityEngine;

public class GlobalStringVar : MonoBehaviour
{
    public const string HORIZONTAL_AXIS = "Horizontal";
    public const string VERTICAL_AXIS = "Vertical";
    public const string JUMP = "Jump";
    public const string ATTACK = "Fire1";
}
